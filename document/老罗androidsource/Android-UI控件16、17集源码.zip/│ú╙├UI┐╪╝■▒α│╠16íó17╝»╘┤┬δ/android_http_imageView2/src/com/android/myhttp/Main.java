package com.android.myhttp;

import java.io.IOException;
import java.io.InputStream;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class Main extends Activity {
	/** Called when the activity is first created. */
	private Button button;
	private ImageView imageView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		button = (Button) this.findViewById(R.id.button);
		imageView = (ImageView) this.findViewById(R.id.imageview);
		button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// try {
				// InputStream inputStream = HttpUtils
				// .getImageViewInputStream();
				// Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
				// imageView.setImageBitmap(bitmap);
				// } catch (IOException e) {
				// // TODO: handle exception
				// }
				byte[] data = HttpUtils.getImageViewArray();
				Bitmap bitmap = BitmapFactory.decodeByteArray(data, 0,
						data.length);
				imageView.setImageBitmap(bitmap);

			}
		});
	}
}