package com.android.myintent;

import java.io.ByteArrayInputStream;
import java.io.ObjectInputStream;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.text.ClipboardManager;
import android.util.Base64;
import android.widget.TextView;

public class OtherActivity extends Activity {

	private TextView textView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.other);
		textView = (TextView) this.findViewById(R.id.msg);
		ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
		String msgString = clipboardManager.getText().toString();
		byte[] base64_byte = Base64.decode(msgString, Base64.DEFAULT);
		ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(
				base64_byte);
		try {
			ObjectInputStream objectInputStream = new ObjectInputStream(
					byteArrayInputStream);
			MyData myData = (MyData) objectInputStream.readObject();
			textView.setText(myData.toString());
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
}
