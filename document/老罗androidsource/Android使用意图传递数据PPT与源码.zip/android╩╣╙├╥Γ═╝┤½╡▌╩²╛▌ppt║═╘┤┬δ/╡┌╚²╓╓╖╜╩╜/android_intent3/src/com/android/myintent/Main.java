package com.android.myintent;

import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;
import java.net.ContentHandler;

import android.R.color;
import android.R.integer;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.ClipboardManager;
import android.util.Base64;
import android.view.View;
import android.widget.Button;

public class Main extends Activity {
	/** Called when the activity is first created. */
	private Button button;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		button = (Button) this.findViewById(R.id.button);
		button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// ��androidϵͳ�е��ü��а�ķ���
//				ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
//				String name = "jack";
//				clipboardManager.setText(name);
//				Intent intent = new Intent(Main.this, OtherActivity.class);
//				startActivity(intent);
				MyData myData = new MyData("jack", 23);
				//������ת�����ַ���
				ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
				String base64String = "";
				try {
					ObjectOutputStream objectOutputStream = new ObjectOutputStream(byteArrayOutputStream);
					objectOutputStream.writeObject(myData);
					base64String = Base64.encodeToString(byteArrayOutputStream.toByteArray(), Base64.DEFAULT);
					objectOutputStream.close();
				} catch (Exception e) {
					// TODO: handle exception
				}
				ClipboardManager clipboardManager = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
				clipboardManager.setText(base64String);
				Intent intent =new Intent(Main.this,OtherActivity.class);
				startActivity(intent);
			}
		});
	}
}