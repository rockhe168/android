package com.android.myintent;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Main extends Activity {
	/** Called when the activity is first created. */
	private Button button;
	private final static int REQUESTCODE = 1;//���صĽ����
    private EditText one,two,result;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		button = (Button) this.findViewById(R.id.button);
		one = (EditText)this.findViewById(R.id.one);
		two = (EditText)this.findViewById(R.id.two);
		result = (EditText)this.findViewById(R.id.result);
		button.setOnClickListener(new View.OnClickListener() {
        
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				int a = Integer.parseInt(one.getText().toString());
				int b = Integer.parseInt(two.getText().toString());
				Intent intent = new Intent(Main.this, OtherActivity.class);
				intent.putExtra("a", a);
				intent.putExtra("b", b);
				//����Intent
				startActivityForResult(intent, REQUESTCODE);// ��ʾ���Է��ؽ��
			}
		});
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
		if(resultCode==2){
			if(requestCode==REQUESTCODE){
				int three = data.getIntExtra("three", 0);
				result.setText(String.valueOf(three));
			}
		}
	}
}