package com.sax.service;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import com.sax.handler.MyHandler;

public class SaxService {

	public SaxService() {
		// TODO Auto-generated constructor stub
	}

	public static List<HashMap<String, String>> readXML(
			InputStream inputStream, String nodeName) {
		try {
			// ����һ������xml�Ĺ�������
			SAXParserFactory spf = SAXParserFactory.newInstance();
			SAXParser parser = spf.newSAXParser();// ����xml
			MyHandler handler = new MyHandler(nodeName);
			parser.parse(inputStream, handler);
			inputStream.close();
			return handler.getList();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}
}
