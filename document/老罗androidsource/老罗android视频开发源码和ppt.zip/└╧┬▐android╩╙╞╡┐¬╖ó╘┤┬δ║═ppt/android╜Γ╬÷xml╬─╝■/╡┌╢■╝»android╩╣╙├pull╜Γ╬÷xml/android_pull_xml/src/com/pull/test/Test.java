package com.pull.test;

import java.io.InputStream;
import java.util.List;

import com.pull.domain.Person;
import com.pull.http.HttpUtils;
import com.pull.parser.PullXMLTools;

public class Test {

	public Test() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String path = "http://192.168.0.102:8080/myhttp/person.xml";
		InputStream inputStream = HttpUtils.getXML(path);
		List<Person> list = null;
		try {
			list = PullXMLTools.parseXML(inputStream, "utf-8");
			for (Person person : list) {
				System.out.println(person.toString());
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
