package com.product.dbutil.login.service;

import java.util.List;

public interface LoginService {

	public boolean login(List<Object> params);
}
