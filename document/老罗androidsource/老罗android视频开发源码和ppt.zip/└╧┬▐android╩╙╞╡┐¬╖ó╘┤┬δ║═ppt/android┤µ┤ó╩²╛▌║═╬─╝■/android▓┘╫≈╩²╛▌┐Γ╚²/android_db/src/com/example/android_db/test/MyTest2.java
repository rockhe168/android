package com.example.android_db.test;

import java.util.List;
import java.util.Map;

import com.example.android_db.dao.PersonDao2;
import com.example.android_db.service.PersonService2;

import android.content.ContentValues;
import android.test.AndroidTestCase;
import android.view.ViewDebug.FlagToString;

public class MyTest2 extends AndroidTestCase {

	public MyTest2() {
		// TODO Auto-generated constructor stub
	}

	public void addPerson() {
		PersonService2 service2 = new PersonDao2(getContext());
		ContentValues values = new ContentValues();// ����map������
		values.put("name", "�ܿ�");
		values.put("address", "XX");
		values.put("sex", "��");
		boolean flag = service2.addPerson(values);
		System.out.println("--->>" + flag);
	}

	public void deletePerson() {
		PersonService2 service2 = new PersonDao2(getContext());
		// delete from person where id = ?
		//������ where�ؼ���
		boolean flag = service2.deletePerson(" id = ? ", new String[] { "4" });
		System.out.println("--->>" + flag);
	}
	
	public void updatePerson(){
		PersonService2 service2 = new PersonDao2(getContext());
		ContentValues values = new ContentValues();// ����map������
		values.put("name", "�ܿ�");
		values.put("address", "XX");
		values.put("sex", "Ů");
		boolean flag = service2.updatePerson(values, " id = ? ", new String[]{"2"});
		System.out.println("--->>" + flag);
	}
	
	public void viewPerson(){
		PersonService2 service2 = new PersonDao2(getContext());
		Map<String,String> map = service2.viewPerson(" id = ? ", new String[]{"2"});
		System.out.println("-->>"+map.toString());
	}
	
	public void listPerson(){
		PersonService2 service2 = new PersonDao2(getContext());
		//select * from person
		List<Map<String,String>> list = service2.listPersonMaps(null, null);
		System.out.println("-->>"+list.toString());
	}
}
