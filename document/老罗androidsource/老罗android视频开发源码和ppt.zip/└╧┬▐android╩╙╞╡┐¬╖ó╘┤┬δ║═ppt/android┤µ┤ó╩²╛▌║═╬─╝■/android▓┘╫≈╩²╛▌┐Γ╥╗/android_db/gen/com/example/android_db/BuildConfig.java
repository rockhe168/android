/** Automatically generated file. DO NOT MODIFY */
package com.example.android_db;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}