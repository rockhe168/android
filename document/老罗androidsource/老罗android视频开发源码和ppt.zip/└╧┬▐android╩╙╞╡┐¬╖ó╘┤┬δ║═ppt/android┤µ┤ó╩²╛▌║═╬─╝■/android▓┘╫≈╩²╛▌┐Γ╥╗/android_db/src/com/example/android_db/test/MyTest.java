package com.example.android_db.test;

import com.example.android_db.db.DbOpenHelper;

import android.test.AndroidTestCase;

public class MyTest extends AndroidTestCase {

	public MyTest() {
		// TODO Auto-generated constructor stub
	}
	
	public void createDb(){
		DbOpenHelper helper = new DbOpenHelper(getContext());
		helper.getWritableDatabase();
	}

}
