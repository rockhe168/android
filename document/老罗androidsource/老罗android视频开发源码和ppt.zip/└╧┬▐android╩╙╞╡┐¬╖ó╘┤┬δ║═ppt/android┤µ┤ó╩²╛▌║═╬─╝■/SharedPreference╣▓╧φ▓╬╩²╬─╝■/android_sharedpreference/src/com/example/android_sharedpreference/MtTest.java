package com.example.android_sharedpreference;

import java.util.Map;

import android.content.Context;
import android.test.AndroidTestCase;
import android.util.Log;

public class MtTest extends AndroidTestCase {

	private String TAG = "MtTest";

	public MtTest() {
		// TODO Auto-generated constructor stub
	}

	public void save() {
		Context context = getContext();
		MySharedpreference mySharedpreference = new MySharedpreference(context);
		boolean flag = mySharedpreference.saveMessage("admin", "123");
		Log.i(TAG, "-->>" + flag);
	}

	public void find() {
		Context context = getContext();
		MySharedpreference sharedpreference = new MySharedpreference(context);
		Map<String, Object> map = sharedpreference.getMessage();
		Log.i(TAG, "--->>" + map.toString());
	}
}
