package com.example.android_contentprovider2;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.test.AndroidTestCase;

public class MyTest extends AndroidTestCase {

	public MyTest() {
		// TODO Auto-generated constructor stub
	}

	public void insert() {
		// ���������ṩ�ߵĲ��裺
		// 1����Ҫһ�����ݽ�����
		ContentResolver contentResolver = getContext().getContentResolver();
		// ʹ��content://+��Ȩ·��
		Uri url = Uri
				.parse("content://com.example.android_contentprovider2.StudentProvider/student");
		ContentValues values = new ContentValues();
		values.put("name", "����");
		values.put("address", "����");
		contentResolver.insert(url, values);
	}

	public void delete() {
		ContentResolver contentResolver = getContext().getContentResolver();
		// ɾ�����м�¼,���Ҫɾ�����м�¼��content://com.example.android_contentprovider2.StudentProvider/student
		Uri uri = Uri
				.parse("content://com.example.android_contentprovider2.StudentProvider/student/1");
		contentResolver.delete(uri, null, null);
	}

	public void update() {
		ContentResolver contentResolver = getContext().getContentResolver();
		Uri uri = Uri
				.parse("content://com.example.android_contentprovider2.StudentProvider/student/2");
		ContentValues values = new ContentValues();
		values.put("name", "��˹");
		values.put("address", "�Ϻ�");
		contentResolver.update(uri, values, null, null);
	}
	
	public void query(){
		ContentResolver contentResolver = getContext().getContentResolver();
		//��ѯ������¼��content://com.example.android_contentprovider2.StudentProvider/student/2
		//��ѯ������¼��content://com.example.android_contentprovider2.StudentProvider/student
		Uri uri = Uri
				.parse("content://com.example.android_contentprovider2.StudentProvider/student");
		//select *  from student where id = 2;
		Cursor cursor = contentResolver.query(uri, null, null, null, null);
		while(cursor.moveToNext()){
			System.out.println("---->>"+cursor.getString(cursor.getColumnIndex("name")));
		}
	}
}
