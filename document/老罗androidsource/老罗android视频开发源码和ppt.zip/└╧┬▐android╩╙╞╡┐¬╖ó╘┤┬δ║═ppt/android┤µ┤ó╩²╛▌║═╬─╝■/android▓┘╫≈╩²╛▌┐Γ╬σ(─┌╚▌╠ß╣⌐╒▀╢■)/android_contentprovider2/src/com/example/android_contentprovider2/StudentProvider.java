package com.example.android_contentprovider2;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.util.Log;

public class StudentProvider extends ContentProvider {

	private final String TAG = "StudentProvider";

	private DbHelper helper = null;

	private static final UriMatcher URI_MATCHER = new UriMatcher(
			UriMatcher.NO_MATCH);
	private static final int STUDENT = 1;// ����������¼
	private static final int STUDENTS = 2;// ����������¼
	static {
		URI_MATCHER.addURI(
				"com.example.android_contentprovider2.StudentProvider",
				"student", STUDENTS);

		URI_MATCHER.addURI(
				"com.example.android_contentprovider2.StudentProvider",
				"student/#", STUDENT);
	}

	public StudentProvider() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		int count = -1;// Ӱ�����ݿ������
		try {
			int flag = URI_MATCHER.match(uri);
			SQLiteDatabase database = helper.getWritableDatabase();
			switch (flag) {
			case STUDENT:
				// content://com.example.android_contentprovider2.StudentProvider/student/1
				// delete from student where id = ? //id ͨ���ͻ��˴��ݹ�����
				long id = ContentUris.parseId(uri);
				String where_value = " id = " + id;
				if (selection != null && !selection.equals("")) {
					where_value += " and " + selection;
				}
				count = database.delete("student", where_value, selectionArgs);
				break;
			case STUDENTS:
				count = database.delete("student", selection, selectionArgs);
				break;
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return count;
	}

	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		int flag = URI_MATCHER.match(uri);
		switch (flag) {
		case STUDENT:
			return "vnd.android.cursor.item/student";
		case STUDENTS:
			return "vnd.android.cursor.dir/students";
		}
		return null;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		// TODO Auto-generated method stub
		// insert into student () (?,?);
		Uri resultUri = null;
		int flag = URI_MATCHER.match(uri);
		switch (flag) {
		case STUDENTS:
			SQLiteDatabase database = helper.getWritableDatabase();
			long id = database.insert("student", null, values);// ���뵱ǰ�е��к�
			resultUri = ContentUris.withAppendedId(uri, id);
			break;
		}
		Log.i(TAG, "---->>" + resultUri.toString());
		return resultUri;
	}

	@Override
	public boolean onCreate() {
		// TODO Auto-generated method stub
		helper = new DbHelper(getContext());
		return true;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		// TODO Auto-generated method stub
		Cursor cursor = null;
		try {
			SQLiteDatabase database = helper.getReadableDatabase();
			int flag = URI_MATCHER.match(uri);
			switch (flag) {
			case STUDENT:
				long id = ContentUris.parseId(uri);
				String where_value = " id = " + id;
				if (selection != null && !selection.equals("")) {
					where_value += " and " + selection;
				}
				cursor = database.query("student", null, where_value,
						selectionArgs, null, null, null, null);
				break;
			case STUDENTS:
				cursor = database.query("student", null, selection,
						selectionArgs, null, null, null);
				break;
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return cursor;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO Auto-generated method stub
		int count = -1;
		try {
			// update table set name = ? ,address = ? where id = ?
			SQLiteDatabase database = helper.getWritableDatabase();
			long id = ContentUris.parseId(uri);
			int flag = URI_MATCHER.match(uri);
			switch (flag) {
			case STUDENT:
				String where_value = " id = " + id;
				if (selection != null && !selection.equals("")) {
					where_value += " and " + selection;
				}
				count = database.update("student", values, where_value,
						selectionArgs);
				break;

			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		return count;
	}

}
