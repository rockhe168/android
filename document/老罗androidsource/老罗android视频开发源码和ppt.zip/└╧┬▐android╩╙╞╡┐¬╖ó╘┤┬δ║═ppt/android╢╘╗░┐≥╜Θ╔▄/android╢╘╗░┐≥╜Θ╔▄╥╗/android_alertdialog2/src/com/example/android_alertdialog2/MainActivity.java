package com.example.android_alertdialog2;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnMultiChoiceClickListener;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends Activity {

	private Button button;
	private Button button2;
	private Button button3;
	private Button button4;
	// ����3��item�б�ѡ��
	private final CharSequence[] items = { "����", "�Ϻ�", "����" };

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		button = (Button) this.findViewById(R.id.button1);
		button2 = (Button) this.findViewById(R.id.button2);
		button3 = (Button) this.findViewById(R.id.button3);
		button4 = (Button) this.findViewById(R.id.button4);
		button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				AlertDialog.Builder builder = new AlertDialog.Builder(
						MainActivity.this);
				builder.setTitle("��ʾ");
				builder.setMessage("��ȷ��Ҫɾ����");
				builder.setIcon(R.drawable.ic_action_search);
				builder.setPositiveButton("ȷ��", new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						// ����û��Ĳ���������ɾ�����ݡ��ύ�����
						// dialog.dismiss();//�öԻ�����ʧ
					}
				});
				builder.setNegativeButton("ȡ��", new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						// ȡ���û��Ĳ�����������ֹͣ����
					}
				});
				builder.setNeutralButton("����", new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						// �����û��Ĳ���
					}
				});
				AlertDialog alertDialog = builder.create();
				alertDialog.show();// �öԻ�����ʾ
			}
		});

		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				AlertDialog.Builder builder = new AlertDialog.Builder(
						MainActivity.this);
				builder.setTitle("��ѡ�����³���");
				// builder.setMessage("��ѡ�����³���");//��������Message������
				builder.setItems(items, new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						CharSequence select_item = items[which];
						Toast.makeText(MainActivity.this, "-->>" + select_item,
								1).show();
					}
				});
				AlertDialog dialog = builder.create();
				dialog.show();
			}
		});

		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				AlertDialog.Builder builder = new AlertDialog.Builder(
						MainActivity.this);
				builder.setTitle("��ѡ�����³���");
				builder.setSingleChoiceItems(items, -1, new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						CharSequence select_item = items[which];
						Toast.makeText(MainActivity.this, select_item, 1)
								.show();
						dialog.dismiss();
					}
				});
				AlertDialog dialog = builder.create();
				dialog.show();
			}
		});
		button4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				AlertDialog.Builder builder = new AlertDialog.Builder(
						MainActivity.this);
				builder.setTitle("��ѡ�����³���");
				// �ڶ���������������Ϊnull����ʾû��ѡ��Ĭ�ϱ�ѡ��
				//ʹ��StringBuffer ׷�ӣ��м��ö��ŷָ���
				builder.setMultiChoiceItems(R.array.city, new boolean[] { false,
						false, false }, new OnMultiChoiceClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which,
							boolean isChecked) {
					}
				});
				builder.setPositiveButton("ȷ��", new OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						//ֱ�ӻ�ȡdialog ��ѡ�е�ֵ
					}
				});
				AlertDialog dialog = builder.create();
				dialog.show();
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}
}
