package com.example.android_alertdialog_progress;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class CustomDialog {

	private Context context;
	private Dialog dialog;

	public CustomDialog(Context context) {
		this.context = context;
		// TODO Auto-generated constructor stub
		dialog = new Dialog(context);
	}

	public void show() {
		View view = LayoutInflater.from(context).inflate(
				R.layout.custom_dialog, null);
		// setContentView(R.layout.custom_dialog);//�����Զ���Ի���Ĳ���
		dialog.setContentView(view);
		dialog.setTitle("�Զ���ĶԻ���");
		TextView textView = (TextView) view.findViewById(R.id.text);
		textView.setText("��ã��Զ���Ի���");
		textView.setTextColor(Color.BLACK);
		ImageView imageView = (ImageView) view.findViewById(R.id.image);
		imageView.setImageResource(R.drawable.pro6);
		dialog.show();
	}

}
