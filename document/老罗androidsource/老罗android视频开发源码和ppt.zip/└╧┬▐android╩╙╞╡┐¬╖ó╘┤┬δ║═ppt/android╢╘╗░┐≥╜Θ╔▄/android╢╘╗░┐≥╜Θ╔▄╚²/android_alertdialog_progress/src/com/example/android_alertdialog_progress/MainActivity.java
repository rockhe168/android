package com.example.android_alertdialog_progress;

import android.os.Bundle;
import android.app.Activity;
import android.app.ProgressDialog;
import android.view.Menu;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {

	private Button button;
	private Button button2;
	private Button button3;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		button = (Button) this.findViewById(R.id.button1);
		button2 = (Button) this.findViewById(R.id.button2);
		button3 = (Button) this.findViewById(R.id.button3);
		button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// ProgressDialog.show(MainActivity.this, "��ʾ",
				// "���ڼ��أ����Ժ�.....");
				ProgressDialog dialog = new ProgressDialog(MainActivity.this);
				dialog.setTitle("��ʾ");
				dialog.setMessage("���ڼ��أ����Ժ�.....");
				dialog.show();// ��ʾ�Ի���
				// dialog.dismiss();//���ضԻ���,����̻߳�����Ϣʹ��
			}
		});
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				// new ProgressDialog(MainActivity.this,
				// ProgressDialog.STYLE_HORIZONTAL);��һ�ַ�ʽ
				ProgressDialog dialog = new ProgressDialog(MainActivity.this);
				dialog.setTitle("������ʾ");
				dialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
				dialog.setProgress(50);// ��������̲߳�����
				dialog.setCancelable(false);
				dialog.show();
			}
		});
		button3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				CustomDialog dialog = new CustomDialog(MainActivity.this);
				dialog.show();
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}
}
