package com.android.MyDatePicker;

import java.util.Calendar;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.TimePicker.OnTimeChangedListener;
import android.widget.Toast;

public class Main extends Activity implements OnClickListener {
	/** Called when the activity is first created. */
	private DatePicker datePicker;
	private TimePicker timePicker;
	private Button button, button2;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		datePicker = (DatePicker) this.findViewById(R.id.mypicker);
		timePicker = (TimePicker) this.findViewById(R.id.timepicker);
		button = (Button) this.findViewById(R.id.button);
		button2 = (Button) this.findViewById(R.id.button2);
		button.setOnClickListener(this);
		button2.setOnClickListener(this);

		Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		int monthOfYear = calendar.get(Calendar.MONTH);
		int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
		datePicker.init(year, monthOfYear, dayOfMonth,
				new DatePicker.OnDateChangedListener() {
					public void onDateChanged(DatePicker view, int year,
							int monthOfYear, int dayOfMonth) {
						// TODO Auto-generated method stub
						StringBuffer buffer = new StringBuffer();
						buffer.append(year + "-" + monthOfYear + "-"
								+ dayOfMonth);
						Toast.makeText(Main.this, buffer.toString(), 1).show();
					}
				});
		timePicker.setIs24HourView(true);// �����Ƿ���24Сʱ��
		int currentHour = calendar.get(Calendar.HOUR);
		int currentMinute = calendar.get(Calendar.MINUTE);
		timePicker.setCurrentHour(currentHour);
		timePicker.setCurrentMinute(currentMinute);
		timePicker.setOnTimeChangedListener(new OnTimeChangedListener() {

			public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
				// TODO Auto-generated method stub

			}
		});
	}

	public void onClick(View v) {
		Calendar calendar = Calendar.getInstance();
		int year = calendar.get(Calendar.YEAR);
		int monthOfYear = calendar.get(Calendar.MONTH);
		int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
		int currentHour = calendar.get(Calendar.HOUR);
		int currentMinute = calendar.get(Calendar.MINUTE);
		switch (v.getId()) {
		case R.id.button:
			DatePickerDialog datePickerDialog = new DatePickerDialog(Main.this,
					new MyOnDateSetListener(), year, monthOfYear, dayOfMonth);
			datePickerDialog.show();
			break;

		case R.id.button2:
            TimePickerDialog timePickerDialog = new TimePickerDialog(Main.this, new MyOnTimeSetListener(), currentHour, currentMinute, true);
            timePickerDialog.show();
            break;
		}
	}
	
	class MyOnTimeSetListener implements TimePickerDialog.OnTimeSetListener{

		public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
			// TODO Auto-generated method stub
			
		}
		
	}

	class MyOnDateSetListener implements DatePickerDialog.OnDateSetListener {

		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			// TODO Auto-generated method stub
			StringBuffer buffer = new StringBuffer();
			buffer.append(year + "-" + monthOfYear + "-"
					+ dayOfMonth);
			Toast.makeText(Main.this, buffer.toString(), 1).show();
		}

	}
}