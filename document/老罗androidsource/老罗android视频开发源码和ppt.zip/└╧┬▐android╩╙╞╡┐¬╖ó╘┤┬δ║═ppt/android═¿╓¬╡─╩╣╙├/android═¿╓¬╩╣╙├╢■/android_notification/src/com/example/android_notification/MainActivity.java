package com.example.android_notification;

import android.net.Uri;
import android.os.Bundle;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.RemoteViews;

public class MainActivity extends Activity {

	private Button button;
	private NotificationManager manager;
	private Notification.Builder builder;
	private Button button2;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		button = (Button) this.findViewById(R.id.button1);
		button2 = (Button) this.findViewById(R.id.button2);
		manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);// ����һ��֪ͨ�Ĺ�����
		builder = new Notification.Builder(this);
		button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(MainActivity.this,
						MainActivity.class);
				PendingIntent contentIntent = PendingIntent.getActivity(
						MainActivity.this, 0, intent, 0);
				builder.setContentIntent(contentIntent);
				builder.setContentTitle("new notification is coming");
				builder.setContentText("hellow world");
				builder.setTicker("��֪ͨ����");// ��һ�γ�����״̬��������
				builder.setSmallIcon(R.drawable.notification);
				// Notification.DEFAULT_ALL ���е���ʾ����Ĭ�ϵ�
				// DEFAULT_LIGHTS Ĭ�ϵ�����
				// DEFAULT_SOUND Ĭ�ϵ�����
				// DEFAULT_VIBRATE Ĭ�ϵ��� <uses-permission
				// android:name="android.permission.VIBRATE"/>
				// builder.setDefaults(Notification.DEFAULT_ALL);
				// Uri uri = Uri.parse("file:///mnt/sdcard/XXX.mp3");
				// builder.setSound(uri);//��ʾ�û������Զ�����������
				Notification notification = builder.build();// ���������ڸ߰汾4.1��ʹ��
				// notification.defaults=Notification.DEFAULT_SOUND;�ڵͰ汾��ʹ�õ�
				manager.notify(1000, notification);
			}
		});
		button2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				RemoteViews contentViews = new RemoteViews(getPackageName(),
						R.layout.custom_notification);
				contentViews.setImageViewResource(R.id.image,
						R.drawable.notification);
				contentViews.setTextViewText(R.id.title, "�Զ���֪ͨ�ı���");
				contentViews.setTextViewText(R.id.text, "�Զ���֪ͨ������");

				Intent intent = new Intent(MainActivity.this,
						MainActivity.class);
				PendingIntent pendingIntent = PendingIntent.getActivity(
						MainActivity.this, 0, intent, 0);
				builder.setContentIntent(pendingIntent);
				builder.setContent(contentViews);// ָ���Զ��岼��
				Notification notification = builder.build();
				manager.notify(1001, notification);
			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}
}
