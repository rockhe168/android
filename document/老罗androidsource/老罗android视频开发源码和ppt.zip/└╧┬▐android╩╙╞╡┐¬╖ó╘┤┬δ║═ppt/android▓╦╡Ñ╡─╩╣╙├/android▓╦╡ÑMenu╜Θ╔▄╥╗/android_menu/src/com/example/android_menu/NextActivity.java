package com.example.android_menu;

import android.app.Activity;
import android.os.Bundle;

public class NextActivity extends Activity {

	public NextActivity() {
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.next);
	}
}
