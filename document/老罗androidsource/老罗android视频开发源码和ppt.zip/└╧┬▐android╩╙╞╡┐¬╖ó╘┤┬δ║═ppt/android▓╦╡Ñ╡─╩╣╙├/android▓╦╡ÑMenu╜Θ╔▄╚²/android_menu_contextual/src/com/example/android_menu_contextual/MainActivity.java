package com.example.android_menu_contextual;

import java.util.ArrayList;
import java.util.List;

import android.os.Bundle;
import android.app.Activity;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends Activity {

	private ListView listView;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		listView = (ListView) this.findViewById(R.id.listView1);
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, getData());
		listView.setAdapter(adapter);
		//��ListViewע�������Ĳ˵�
		registerForContextMenu(listView);//View����
	}

	public List<String> getData() {
		List<String> list = new ArrayList<String>();
		for (int i = 1; i <= 7; i++) {
			list.add("jack" + i);
		}
		return list;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}
	
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		// ����xml�е������Ĳ˵�
		super.onCreateContextMenu(menu, v, menuInfo);
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.activity_main, menu);
	}
	//��Ӧ�����Ĳ˵��Ĳ���
	@Override
	public boolean onContextItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case R.id.delete:
			Toast.makeText(MainActivity.this, "Delete", 1).show();
			break;
		case R.id.share:
			Toast.makeText(MainActivity.this, "Share", 1).show();
			break;
		case R.id.edit:
			Toast.makeText(MainActivity.this, "Edit", 1).show();
			break;
		}
		return super.onContextItemSelected(item);
	}
}
