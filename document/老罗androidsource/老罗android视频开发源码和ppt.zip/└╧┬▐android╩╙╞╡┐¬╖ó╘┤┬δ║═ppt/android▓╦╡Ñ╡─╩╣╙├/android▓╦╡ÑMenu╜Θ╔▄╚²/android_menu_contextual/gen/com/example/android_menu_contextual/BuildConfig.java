/** Automatically generated file. DO NOT MODIFY */
package com.example.android_menu_contextual;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}