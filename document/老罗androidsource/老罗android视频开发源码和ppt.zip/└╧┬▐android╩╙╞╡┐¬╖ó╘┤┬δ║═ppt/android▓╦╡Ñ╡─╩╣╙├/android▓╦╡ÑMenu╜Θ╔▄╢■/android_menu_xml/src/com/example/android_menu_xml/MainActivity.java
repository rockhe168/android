package com.example.android_menu_xml;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends Activity {

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case R.id.create_new:
			Intent intent = new Intent(MainActivity.this, SystemMenu.class);
			item.setIntent(intent);
			break;

		case R.id.open:
			Toast.makeText(MainActivity.this, "�򿪲˵�", 1).show();
			break;
		case R.id.load:
			Toast.makeText(MainActivity.this, "���ز˵�", 1).show();
			break;
		case R.id.save:
			Toast.makeText(MainActivity.this, "����˵�", 1).show();
			break;
		}

		return super.onMenuItemSelected(featureId, item);
	}
}
