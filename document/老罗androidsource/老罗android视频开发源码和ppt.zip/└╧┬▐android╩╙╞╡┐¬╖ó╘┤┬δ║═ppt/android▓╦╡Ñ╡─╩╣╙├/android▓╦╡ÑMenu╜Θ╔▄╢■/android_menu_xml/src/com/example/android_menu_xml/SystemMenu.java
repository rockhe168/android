package com.example.android_menu_xml;

import android.app.Activity;
import android.os.Bundle;

public class SystemMenu extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sysmenu);
	}
}
