/** Automatically generated file. DO NOT MODIFY */
package com.example.android_menu_xml;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}