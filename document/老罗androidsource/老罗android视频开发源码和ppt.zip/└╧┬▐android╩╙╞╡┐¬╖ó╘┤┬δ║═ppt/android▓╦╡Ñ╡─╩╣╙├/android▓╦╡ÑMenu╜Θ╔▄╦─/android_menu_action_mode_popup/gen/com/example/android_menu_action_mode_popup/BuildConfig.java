/** Automatically generated file. DO NOT MODIFY */
package com.example.android_menu_action_mode_popup;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}