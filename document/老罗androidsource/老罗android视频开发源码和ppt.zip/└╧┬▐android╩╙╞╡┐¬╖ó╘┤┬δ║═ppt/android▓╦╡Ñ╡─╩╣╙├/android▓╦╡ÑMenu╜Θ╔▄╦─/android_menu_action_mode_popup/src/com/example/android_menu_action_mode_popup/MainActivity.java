package com.example.android_menu_action_mode_popup;

import android.app.Activity;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnLongClickListener;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.PopupMenu.OnMenuItemClickListener;
import android.widget.Toast;

public class MainActivity extends Activity {

	private Button button;
	private ActionMode actionMode;// ʹ��ActionMode��ɲ˵�����
    private Button button2;
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		button = (Button) this.findViewById(R.id.button1);
		button.setOnLongClickListener(new OnLongClickListener() {
			@Override
			public boolean onLongClick(View v) {
				// TODO Auto-generated method stub
				if (actionMode != null) {
					return false;
				}
				actionMode = startActionMode(actionCallback);
				v.setSelected(true);
				return true;
			}
		});
		
		button2 = (Button)this.findViewById(R.id.button2);
		button2.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				PopupMenu popupMenu = new PopupMenu(MainActivity.this, v);
				popupMenu.setOnMenuItemClickListener(new OnMenuItemClickListener() {
					@Override
					public boolean onMenuItemClick(MenuItem item) {
						// TODO Auto-generated method stub
						switch (item.getItemId()) {
						case R.id.edit:
							edit();
							break;
						case R.id.delete:
							Toast.makeText(MainActivity.this, "Delete", 1).show();
							break;

						case R.id.share:
							Toast.makeText(MainActivity.this, "Share", 1).show();
							break;
						}
						return false;
					}
				});
				MenuInflater inflater = popupMenu.getMenuInflater();
				inflater.inflate(R.menu.activity_main, popupMenu.getMenu());
				popupMenu.show();//��ʾ�˵�
			}
		});
	}

	private ActionMode.Callback actionCallback = new ActionMode.Callback() {
		@Override
		public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public void onDestroyActionMode(ActionMode mode) {
			// TODO Auto-generated method stub
			actionMode = null;
		}

		// ��ʾ����Ҫ���ز˵�����xml�м���
		@Override
		public boolean onCreateActionMode(ActionMode mode, Menu menu) {
			// TODO Auto-generated method stub
			MenuInflater inflater = getMenuInflater();
			inflater.inflate(R.menu.activity_main, menu);
			return true;
		}

		@Override
		public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
			// TODO Auto-generated method stub
			switch (item.getItemId()) {
			case R.id.edit:
				edit();
				break;

			case R.id.delete:
				Toast.makeText(MainActivity.this, "Delete", 1).show();
				break;

			case R.id.share:
				Toast.makeText(MainActivity.this, "Share", 1).show();
				break;
			}
			return false;
		}
	};

	public void edit() {
		Toast.makeText(MainActivity.this, "Edit", 1).show();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}
}
